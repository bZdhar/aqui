package com.nekiskill.system_skills;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemSkillsApplicationTests {

	@Test
	void contextLoads() {
	}

}
