package com.nekiskill.system_skills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemSkillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemSkillsApplication.class, args);
	}

}
